//
//  PayPalCheckout.h
//  PayPalCheckout
//
//  Created by Winton, Cody on 8/28/19.
//  Copyright © 2019 PayPal. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PayPalCheckout.
FOUNDATION_EXPORT double PayPalCheckoutVersionNumber;

//! Project version string for PayPalCheckout.
FOUNDATION_EXPORT const unsigned char PayPalCheckoutVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PayPalCheckout/PublicHeader.h>


